.model small
.data
  ;msg1 DB "1-Hola mundo" ,10, 13, '$'
  ;msg2 DB "2-Hola mundo2","$"
  msg1 DB "A" ,10, 13, '$'
  msg2 DB "B" ,10, 13, '$'   
  
  vNum db 0,1,2,3,4    ; 5 variables bytes inicializadas
                            ; en 1,2,3,4,5
  vChar db 'A','B', 'C'; 3 varialbe inicializadas
                            ; en 65, 66,, 67 ASCII
;A = 65 = 0100 0001 = HEX 41
;B = 66 = 0100 0010 = HEX 42
;C = 67 = 0100 0011 = HEX 43  
;$ = 36 = 0010 0100 = hex 24
; ************************************************
; Usando la directiva dup
ArregloD1 db 5 dup(0)    ; arreglo de  5 byte inicializados 
                         ; en cero
ArregloD2 db 5 dup(0),1  ; Arreglo de 6 5 byte inicializados 
                         ; en cero y el ultimo en 1
                      
                            
.code
.startup  

 inicio:
    ;************************************************  
    ;Equivalente a un cout << "hola mundo" << endl;  
    ;************************************************
    mov AH, 09H
    mov DX, Offset msg1
    int 21h
    
    ;************************************************
    ;Equivalente a un cout << "hola mundo2" << endl; 
    ;************************************************  
    mov AH, 09H
    mov DX, Offset msg2
    int 21h
    ;******************************************
    ;evitar que le programa se cierre
    ; es como el system("pause")  o al getch() 
    ;******************************************
    mov ax, 0c07h
    int 21h  
    ;*******************************
    ;INSERTAR                       
    ;*******************************
    ; parte de arreglos
    ; mov [vNum], 5     ; asigne un 5 al primer campo
                        ; vNum[0] = 5
    ; mov [vNum+1], 10  ; asigne un 10 al segundo campo
                        ; vNum[1] = 10
    ;CONSULTAR
    mov ah, [vNum+1] ; ax = vNum[1] 
    
    
    
   ;*******************************
   ;equivalente al return 0 en c++
   ;*******************************
   Salir:   ;Etiqueta para salir del programa
    mov ah,04ch
    int 21h
end