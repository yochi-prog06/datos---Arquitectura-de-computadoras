.model small
.data
  ; sin datos

.code
 imprimeDigito macro parametro
    mov dl, parametro+48
    mov ah, 02h
    int 21h
 endm   

 finaliza macro 
    ;mov ax, oc07h
    mov ax, 0C07h
    int 21h
    .exit
 endm   

 .startup
  imprimeDigito  0
  imprimeDigito  2
  imprimeDigito  20
  
  ;revisar la tabla ascii
  ; 0 + ?
  ; 2 + ?  
  ; 20 + ? = 68 = D   
    
end