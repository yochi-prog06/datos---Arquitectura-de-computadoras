.model small
.data
  msj db 0ah,0dh, 'hola mundo','$' ; 0a = 0000 1010  = 10
                                   ; 0d = 0000 1101  = 13
  msj2 db 0ah,0dh, '2-hola mundo','$' ; string termina con $
  msj3 db 0ah,0dh, 'Digite un numero','$' ; string termina con $

;El signo de d�lares "$" al final de la cadena (denominado centinela)
;es requerido por la funci�n de visualizaci�n de la cadena de MS-DOS.
;La cadena incluye los c�digos para carriage-return y line-feed. 
 
.code
 .startup
    
    ;mov dx,offset msj2    COUT << XXXX
    mov dx,offset msj2
    mov ah,09h
    int 21h   
    
    
   
    ;evitar que le programa se cierre  (system("pause"))
    mov ax, 0c07h
    int 21h 
    
    ;entregar control al SO    return 0;
    mov ah,04ch
    int 21h 
    
  .exit
  
end