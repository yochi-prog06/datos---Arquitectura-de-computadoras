.model small
.data
  ;msg1 DB "1-Hola mundo" ,10, 13, '$'
  ;msg2 DB "2-Hola mundo2","$"
  msg1 DB "A" ,10, 13, '$'
  msg2 DB "B" ,10, 13, '$'
                            
.code
.startup  

 inicio:
      
    ;Equivalente a un cout << "hola mundo" << endl;
    mov AH, 09H
    mov DX, Offset msg1
    int 21h
    
    
    ;Equivalente a un cout << "hola mundo2" << endl;   
    mov AH, 09H
    mov DX, Offset msg2
    int 21h

    ;evitar que le programa se cierre
    ; es como el system("pause")
    mov ax, 0c07h
    int 21h  
    
   
   ;equivalente al return 0 en c++
   Salir:   ;Etiqueta para salir del programa
    mov ah,04ch
    int 21h
end