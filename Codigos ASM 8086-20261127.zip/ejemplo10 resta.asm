; -----------------------------------------
; 214
; RESTA usando registros de proposito general
; ax, bx, cx, dx
; ah  al
; bh  bl
; resultado en complemento A2
; minuendo - sustraedo = resta
; ------------------------------------------
.model small
.data
   ; SIN DATOS

.code
   pintaDigito macro parametro
     ;solo pinta un solo digito
     ;la suma debe dar de un digito
     mov dl, parametro
     add dl, 48    
     mov ah, 02h
     int 21h  ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup   ; **** RESULTADO QUEDA EN AL  *************
   ;mov al, 2 
   ;mov bl, 1
   ;sub al, bl ; resutado 2 -1 = 1
   
   mov al, 1 
   mov bl, 2
   ;sub al, bl ; resutado 1 -2 = -1 (el mostrar debe cambiar)
   sub bl, al ; resutado 2 -1 = 1
   
   pintaDigito al
   finaliza 
    
  end