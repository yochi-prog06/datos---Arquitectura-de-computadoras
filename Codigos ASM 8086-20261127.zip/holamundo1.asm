.model small
.data
  msj db 'hola mundo',10, 13, '$'

.code
 inicio:
    mov ah,09h
    mov dx,offset msj
    int 21h
    ;evitar que le programa se cierre
    mov ax, 0c07h
    int 21h
   Salir:   ;Etiqueta para salir del programa
    mov ah,04ch
    int 21h
end