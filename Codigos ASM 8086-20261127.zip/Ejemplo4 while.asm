; ----------------------------------
; un ciclo  infinito  208
; ----------------------------------
.model small
.data
  ; sin datos

.code
 imprimeDigito macro parametro
    mov dl, parametro+48
    mov ah, 02h
    int 21h
    jmp while:
 endm   

 finaliza macro 
    mov ax, 0c07h
    int 21h
    .exit
 endm   

 .startup
  
  while:
    imprimeDigito  0
       
  ; Hace falta una condicion de salidad del while
  ; esto se hace con una comparacion la cual
  ; usa las BANDERAS de la ALU
    
end