;-----------------------------------
; Bucle con un contador
; inc o
; dec
;-----------------------------------

.model small
.data
   ; SIN DATOS
   a db "son iguales", 13, 10, "$"
   b db "son diferentes", 13, 10, "$"

.code
 
   pintaDigito macro parametro
     mov dl, parametro
     add dl, 48    
     mov ah, 02h  ; imprime SOLO UN DIGITO
     int 21h      ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup   
   
   mov cl, 0 ; para usarla como contador
   
   bucle: 
      pintaDigito cl
      cmp cl, 3   ; condicional de salida del ciclo
      je  salir
      inc cl    ; inc, incrementa el valor del registor en 1
      jmp bucle              
   
     
   salir:
     finaliza 
    
  end