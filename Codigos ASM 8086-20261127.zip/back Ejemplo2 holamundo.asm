;1- ver menu/ascii codes
;-----------------------
;2- menu/assambler/set output direct
;para indicar donde se guarden los archivos
;comentar un bloque
;3-menu edit/comment block
;4- ver hola mundo paso a paso
;Registros
; ax acumulador
; bx base
; cx contado
; dx datos
;5- Dar ejecutar y luego buscar opcion 
; view/ALU 

.model small
.data
  msj db 0ah,0dh,'hola mundo','$';10,13 cambio de linea
  saludo2 db 0ah,0dh,'Hola2 MUNDO2','$'    ; string termina con $
 
;El signo de d�lares "$" al final de la cadena (denominado centinela)
;es requerido por la funci�n de visualizaci�n de la cadena de MS-DOS.
;La cadena incluye los c�digos para carriage-return y line-feed. 
 
 
imprime macro saludo
  mov ax,data
  mov ds,ax   ; ds apunta a segmento donde esta la cadena
  mov ah,09   ; con 09 despliega una cadena de caracteres
  mov dx,offset saludo2  ;dx tiene el desplazamiento dentro del segmento de la cadena
  int 21h
endm 
 
 
.code
 inicio:
    mov ah,09h ; Con 09h imprime a pantalla
    mov dx,offset msj ; obtiene la direccion de mensaje
    int 21h
    
    imprime saludo
    
    ;evitar que le programa se cierre
    mov ax, 0c07h
    int 21h
   Salir:   ;Etiqueta para salir del programa
    mov ah,04ch
    int 21h
end