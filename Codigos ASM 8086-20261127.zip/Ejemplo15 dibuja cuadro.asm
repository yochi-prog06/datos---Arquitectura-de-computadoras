;***************************************************************************************************************
;INT 10H Funci�n 09H
;Escribir car�cter y atributo
;LLAMADA:
;AH = 09H
;AL = C�digo del car�cter a escribir.
;BH = P�gina de v�deo donde escribir el car�cter.
;BL = Atributo � color que va a tener el car�cter.
;CX = Cantidad de veces que se debe escribir el car�cter, uno a continuaci�n de otro.
;DEVUELVE:
;NADA.
;EFECTO:
;Se escribe un car�cter en la posici�n actual del cursor, en la p�gina de v�deo deseada. El car�cter tendr� el color indicado mediante BL.
;***************************************************************************************************************


.model small
.data
.code
; interrupcion 10h = establece modo de video
; recibe = AH = 00h
; recibe = Al = 12h  -->modo video
; devuelve = nada
;-----------------------------------------  
; 00h = resolucion 40x25 texto
; 01h = resolucion 40x25 texto  
; 12h 640x480 grafico *** <-----
 inicio:
    mov ax,0012h ; modo grafico
    int 10h
        
    mov cx, 15; columna
    mov dl, 15; fila
    
 PintaFila:   
    inc cx ; incrementa columna para pintar fila
    ;color
    mov ah, 0ch   ;Escribir car�cter y atributo
    mov al, 09    ;Codigo del car�cter a escribir.
    int 10h
        
    cmp cx, 50
    je PintaColumna  ;si es igual pinta columna
    jmp PintaFila    ;sino salte a la etiqueta
   
 PintaColumna:
     inc dx ; incrementa fila para pintar columna 
     ;color
     mov ah, 0ch
     mov al, 09
     int 10h        
    
     cmp dx, 50
     je Salir
     jmp PintaColumna    
       
PintaOtraCosa:   
    
 color: 
    mov ah, 0ch
    mov al, 09
    int 10h
    
   Salir:   ;Etiqueta para salir del programa
    mov ah,07h
    int 21h
end