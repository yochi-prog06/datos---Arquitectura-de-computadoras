; -----------------------------------------
; consola 211
; suma usando registros de proposito general
; ax, bx, cx, dx
; la suma queda en el primer operando 
; ah  al
; bh  bl
; ------------------------------------------
.model small
.data
   ; SIN DATOS

.code
   pintaDigito macro parametro
     ;solo pinta un solo digito
     ;la suma debe dar de un digito
     ;mov dl, parametro +48
     mov dl, parametro
     add dl, 48  ; resultado queda en dl    
     mov ah, 02h
     int 21h  ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup
   mov al, 5  ;VER paso a paso los registros
   mov bl, 1;5
   add al, bl  ; Resultado queda en AL
   pintaDigito al
   finaliza 
    
   ; qeu pasa si se suma 5 + 5 = 10
   ; 10 = A (10+48 = 58 = ":" en tabla ascii)
end