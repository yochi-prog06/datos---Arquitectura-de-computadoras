.model small
.data
.code
; interrupcion 10h = establece modo de video
; recibe = AH = 00h
; recibe = Al = 12h  -->modo video
; devuelve = nada
;-----------------------------------------  
; 00h = resolucion 40x25 texto
; 01h = resolucion 40x25 texto  
; 12h 640x480 grafico *** <-----
 inicio:
    mov ax,0012h ; modo grafico
    int 10h
        
    mov cx, 15; columna
    mov dl, 15; fila
    
 PintaFila:   
    inc cx ; incrementa columna para pintar fila
    ;color
    mov ah, 0ch
    mov al, 09
    int 10h
        
    cmp cx, 50
    je PintaColumna  ;si es igual pinta columna
    jmp PintaFila    ;sino salte a la etiqueta
   
 PintaColumna:
     inc dx ; incrementa fila para pintar columna 
     ;color
     mov ah, 0ch
     mov al, 09
     int 10h        
    
     cmp dx, 50
     je Salir
     jmp PintaColumna    
       
PintaOtraCosa:   
    
 color: 
    mov ah, 0ch
    mov al, 09
    int 10h
    
   Salir:   ;Etiqueta para salir del programa
    mov ah,07h
    int 21h
end