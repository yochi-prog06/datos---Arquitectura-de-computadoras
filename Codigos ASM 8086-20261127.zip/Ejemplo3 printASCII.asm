.model small
.data
  ; sin datos     
  ; Uso de macros (parecidoa funciones)
  ; se pueden poner parametros
  ; Se requiere la tabla ASCII para comprobar la salida
  ; ASCII - VALOR
  ;  48   - 0
  ;  49   - 1
  ;  50   - 2
  ;  51   - 3
  ;  52   - 4
  ;  53   - 5
  ;  54   - 6
  ;  55   - 7
  ;  56   - 8
  ;  57   - 9
  ; ......
  

.code
 imprimeDigito macro parametro
    mov dl, parametro+48
    mov ah, 02h
    int 21h
 endm   

 finaliza macro 
    ;mov ax, oc07h
    mov ax, 0C07h
    int 21h
    .exit
 endm   

 .startup
  imprimeDigito  0
  imprimeDigito  2
  imprimeDigito  20
  
  ;revisar la tabla ascii
  ; 0 + ?
  ; 2 + ?  
  ; 20 + ? = 68 = D   
    
end