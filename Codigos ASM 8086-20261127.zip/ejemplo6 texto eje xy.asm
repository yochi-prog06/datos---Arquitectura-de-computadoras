; ----------------------------------
; Resultdo:
; Imprime un texto pero empezando en cierta posicion de la pantalla
; consola209
;0,0 fila de esquina izq arriba
; ----------------------------------
.model small
.data
   variable db "hola mundo",13,10, "$"

.code
 imprime_localiza macro texto, x, y
    mov ah,02h
    mov bh,00d
    mov dh,x
    mov dl,y
    int 10h;  interrupcion 
    
    mov ah, 9       ; 09h hex  9 decimal
    lea dx, texto   ; MOV DX, offset texto
    int 21h
 endm   

 finaliza macro 
    mov ax, 0c07h    ; pausa
    int 21h
    
    ;entregar control al SO
    mov ah,04ch
    int 21h 
    
    .exit
 endm   

 .startup
  
  imprime_localiza variable, 0, 0
  imprime_localiza variable, 2, 2
  finaliza
    
end