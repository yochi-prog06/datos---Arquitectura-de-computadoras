.model small
.data
  msj db 0ah,0dh, 'Digite letra hasta que rebiba un ENTER ','$'
  msj2 db 0ah,0dh, 'Su programa ha terminado','$' ; string termina con $
  letra db ''

;El signo de d�lares "$" al final de la cadena (denominado centinela)
;es requerido por la funci�n de visualizaci�n de la cadena de MS-DOS.
;La cadena incluye los c�digos para carriage-return y line-feed. 
 
.code
 .startup  
 
    mov dx,offset msj
    mov ah,09h
    int 21h
       
    ; leer caracter hasta encontrar un ENTER
    leerCaracter:
      mov ah, 01h
      int 21h  ; deja caracter en al
      cmp al, 0dh  ;  0dh= enter (13)
      je finalizar:
      jmp leerCaracter
    
    ; leer caracter
    ;mov ah, 01h
    ;int 21h
    
    
    ;mov dx,offset msj2
   
   
    ;evitar que le programa se cierre
    ;mov ax, 0c07h
    ;int 21h
    ;entregar control al SO
    finalizar:
      mov dx,offset msj2
      mov ah,09h
      int 21h
    ;evitar que le programa se cierre
       mov ax, 0c07h
       int 21h
        
       mov ah,04ch
       int 21h
  .exit
  
end