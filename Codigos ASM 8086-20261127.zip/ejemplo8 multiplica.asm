; -----------------------------------------
; 211
; multilplicacion usando registros de proposito general
; ax, bx, cx, dx
; la suma queda en el primer operando 
; ah  al
; bh  bl
; ------------------------------------------
.model small
.data
   ; SIN DATOS

.code
   pintaDigito macro parametro
     ;solo pinta un solo digito
     ;la suma debe dar de un digito
     mov dl, parametro
     add dl, 48    
     mov ah, 02h
     int 21h  ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup
   mov al, 3 
   mov bl, 2
   ;mul al  ; solo recibe un openrado
           ; multiplica ese operando por lo que haya en AL 
           ; si recibe AL hace al * al
   ;mul al  ;Eje: ver registros y resultado = 9
   mul bl  ;Eje: ver registros y resultado = 6   (3*2 = 6 queda en AL)
   
   pintaDigito al
   finaliza 
    
  end