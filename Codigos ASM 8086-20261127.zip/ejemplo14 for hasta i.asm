;-----------------------------------
; Dividiendo entre 10
; Para imprimir un numero al reves
; entra 1234 y devuelve 4321
; n = numero
; x = divisor
; n/x = resultado y r = residuo
; n = n/10  luego, 1234/10 = 123, residuo 4
; n = n/10  luego, 123/10 = 12, residuo 3
; n = n/10  luego, 12/10 = 1, residuo 2
; se tiene entonces 1-2-3-4            
;https://tutoasm-emu8086.jimdo.com/asm-emu8086/instrucciones-b%C3%A1sicas/
;-----------------------------------

.model small
.data
   ; SIN DATOS
   a db "son iguales", 13, 10, "$"
   b db "son diferentes", 13, 10, "$"

.code
 
   pintaDigito macro parametro
     mov dl, parametro
     add dl, 48    
     mov ah, 02h  ; imprime SOLO UN DIGITO
     int 21h      ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup   
   
   mov cl, 0 ; para usarla como contador
   
   bucle: 
      pintaDigito cl
      cmp cl, 9
      je  salir
      inc cl
      jmp bucle              
   
     
   salir:
     finaliza 
    
  end