; -----------------------------------------
; 215
; DIVISION usando registros de proposito general
; ax, bx, cx, dx
; ah  al
; bh  bl
; dividendo / divisor = cociente  y sobre un Residuo
; ------------------------------------------
.model small
.data
   ; SIN DATOS

.code
   pintaDigito macro parametro
     ;solo pinta un solo digito
     ;la suma debe dar de un digito
     mov dl, parametro
     add dl, 48    
     mov ah, 02h
     int 21h  ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup   ; **** RESULTADO QUEDA EN AL  *************
   ;mov al, 2 
   ;mov bl, 1
   ;sub al, bl ; resutado 2 -1 = 1
   
   mov al, 11; DIVIDENDO 
   mov bl, 3; divisor
   div bl ; solo recibe bl, divide AL entre bl en este caso
          ; cociente se guarda en al
          ; residuo se guarde en ah

   ; dividir entre si mismo
   ; di al
   ; resultado 1   
   pintaDigito al ; ==> Resultado de la division 11/9 = 3
   pintaDigito ah ; ==> Residuo = 2
   
   finaliza 
    
  end