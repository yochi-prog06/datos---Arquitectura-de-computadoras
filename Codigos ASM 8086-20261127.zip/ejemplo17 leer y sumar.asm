.model small
.data
  msj db 0ah,0dh, 'Digite letra hasta que rebiba un ENTER ','$'
  msj2 db 0ah,0dh, 'Su programa ha terminado','$' ; string termina con $
  letra db ''
  msg3 db 0ah,0dh, 'SUMA ','$'  
  msg4 db 0ah,0dh, 'Digite un numero: ','$'   
  
  n1 db 0
  n2 db 0
  suma db 0 
  negativo db -15
  positivo db 15
  menos128 db -128
  posi128  db 128
  menos127 db -127
  posi255  db 255
  neg1     db -1

;El signo de d�lares "$" al final de la cadena (denominado centinela)
;es requerido por la funci�n de visualizaci�n de la cadena de MS-DOS.
;La cadena incluye los c�digos para carriage-return y line-feed. 
 
.code
 .startup  
    
    ;muestra mensaje de leer primer numero
    mov ah, 09h
    lea dx, msg4
    int 21h
    
    ;capturar un numero y lo deja en n1
    mov ah, 01h
    int 21h
    sub al, 30h
    mov n1, al
    
    ;mostra variable
    ;mov ah, 09h
    ;lea dx, n1;
    ;int 21h
       

    ;muestra mensaje de leer segundo numero
    mov ah, 09h
    lea dx, msg4
    int 21h
    
    ;capturar un numero y lo deja en n2
    mov ah, 01h
    int 21h
    sub al, 30h ; 30h = 48 decimal (para tabla ascii)
    mov n2, al

    ;hacer la suma
    mov al,n1 
    add al, n2
    mov suma, al  
    
    mov ah, 09h
    lea dx, msg3
    int 21h
    
    
    mov al, suma
    AAM ; ajuta ascii para incremento, traduce ascci
    mov bx, ax
    
    mov  ah, 02h
    mov dl, bh
    add dl, 30h
    int 21h
             
    mov ah, 02h
    mov dl, bl 
    add dl, 30h
    int 21h
             
             
    
    jmp finalizar
    
    
    ;entregar control al SO
    finalizar:
      mov dx,offset msj2
      mov ah,09h
      int 21h
    ;evitar que le programa se cierre
       mov ax, 0c07h
       int 21h
        
       mov ah,04ch
       int 21h
  .exit
  
end