;-----------------------------------
;jumpers
;  mov cx, 3
;  cmp cx, 3
; je es igual
; jne no es igual
; ja es mayor sin signo
; jb es menor con signo
; jae es mayor o igual
; jbe es menor o igual              
;-----------------------------------

.model small
.data
   ; SIN DATOS
   a db "son iguales", 13, 10, "$"
   b db "son diferentes", 13, 10, "$"

.code

   ImprimeTexto macro texto
     mov ah, 9     ; imprime un string, no solo un caracter
     lea dx, texto ;  se ubica en la posicion de memoria donde esta el texto
     int 21h
   endm
    
   pintaDigito macro parametro
     mov dl, parametro
     add dl, 48    
     mov ah, 02h  ; imprime SOLO UN DIGITO
     int 21h      ; imprima en pantalla
   endm   

   finaliza macro 
     mov ax, 0c07h ; aqui se pierde el resultado
     int 21h       ; de la suma (se sobreescribe el ah y al)
     .exit
   endm   

 .startup   
 
   mov cx, 3
   cmp cx, 4   ; CMP destino, fuente
   ;cmp cx, 3   ; CMP destino, fuente
   
   ;resta el operando fuente al operando destino pero sin 
   ;que �ste almacene el resultado de la operaci�n, solo se 
   ;afecta el estado de las banderas.
   je soniguales     ; salta si es igual a cero
   jne sondiferentes  ; salta si NO es igual a cero
   
   soniguales: 
     ImprimeTexto a
     jmp salir
   
   sondiferentes:  
     ImprimeTexto b
     jmp salir
     
   salir:
     finaliza 
    
  end