; ----------------------------------
; un ciclo  infinito  208
; ----------------------------------
.model small
.data
  ; sin datos

.code
 imprimeDigito macro parametro
    mov dl, parametro+48
    mov ah, 02h
    int 21h
    jmp while:
 endm   

 finaliza macro 
    mov ax, oc07h
    int 21h
    .exit
 endm   

 .startup
  
  while:
    imprimeDigito  0
 
    
end